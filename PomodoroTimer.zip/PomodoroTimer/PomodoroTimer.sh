#!/bin/bash
java -jar Pomodoro*.jar
